﻿using System.Collections;
using System.Collections.Generic;

namespace EasyPolyMap.Core
{
    public class EPMQuadrangle : EPMShape
    {
        public EPMQuadrangle()
        {
            
        }
    }
}


